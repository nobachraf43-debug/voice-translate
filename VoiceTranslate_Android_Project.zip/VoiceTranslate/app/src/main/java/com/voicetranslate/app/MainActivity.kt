package com.voicetranslate.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale
import java.util.UUID

data class TranscriptItem(
    val id: String = UUID.randomUUID().toString(),
    val source: String,
    val arabic: String,
    val language: String
)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var listening = false
    private var paused = false
    private var restarting = false
    private var selectedSource = "auto"
    private var onStatus: ((String) -> Unit)? = null
    private var onPartial: ((String) -> Unit)? = null
    private var onItem: ((TranscriptItem) -> Unit)? = null
    private var onErrorText: ((String) -> Unit)? = null
    private val recentFinals = ArrayDeque<String>()
    private var lastFinalAt = 0L

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else onStatus?.invoke("يرجى السماح باستخدام الميكروفون")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            var status by remember { mutableStateOf("جاهز للبدء") }
            var partial by remember { mutableStateOf("") }
            var items by remember { mutableStateOf(listOf<TranscriptItem>()) }
            var source by remember { mutableStateOf("auto") }
            var autoSpeak by remember { mutableStateOf(true) }
            var speechRate by remember { mutableFloatStateOf(1f) }
            var error by remember { mutableStateOf("") }

            onStatus = { runOnUiThread { status = it } }
            onPartial = { runOnUiThread { partial = it } }
            onErrorText = { runOnUiThread { error = it; status = "حدث خطأ" } }
            onItem = { item ->
                runOnUiThread {
                    items = items + item
                    partial = ""
                    if (autoSpeak) speak(item.arabic, speechRate)
                }
            }
            selectedSource = source

            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF63B8FF),
                    secondary = Color(0xFFB39DFF),
                    background = Color(0xFF090F1D),
                    surface = Color(0xFF131D30)
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF090F1D)) {
                    Column(
                        Modifier.fillMaxSize().padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("VOICE TRANSLATE", color = Color(0xFF8ECFFF),
                            fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("المترجم الصوتي الفوري", color = Color.White,
                            fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("استمع • ترجم • انطق", color = Color.LightGray, fontSize = 13.sp)
                        Spacer(Modifier.height(18.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF14223A)),
                            shape = RoundedCornerShape(22.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("لغة الكلام", color = Color.LightGray)
                                Spacer(Modifier.height(6.dp))
                                var expanded by remember { mutableStateOf(false) }
                                Box {
                                    OutlinedButton(onClick = { expanded = true }) {
                                        Text(sourceLabel(source), color = Color.White)
                                    }
                                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                        listOf("auto", "ru", "en", "fr", "es", "de").forEach { code ->
                                            DropdownMenuItem(
                                                text = { Text(sourceLabel(code)) },
                                                onClick = {
                                                    source = code
                                                    selectedSource = code
                                                    expanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                Text("⬇", color = Color(0xFF63B8FF), fontSize = 22.sp)
                                Text("العربية الفصحى", color = Color.White,
                                    fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(14.dp))
                                Box(
                                    Modifier.size(112.dp).background(
                                        Brush.linearGradient(listOf(Color(0xFF1768B5), Color(0xFF6545B8))),
                                        CircleShape
                                    ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Mic, null, tint = Color.White, modifier = Modifier.size(52.dp))
                                }
                                Spacer(Modifier.height(10.dp))
                                Text(status, color = Color(0xFFB9D8F6), fontSize = 14.sp)
                                if (partial.isNotBlank()) {
                                    Spacer(Modifier.height(8.dp))
                                    Text(partial, color = Color.White, textAlign = TextAlign.Center)
                                }
                                Spacer(Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { requestAndStart() }) {
                                        Icon(Icons.Default.PlayArrow, null)
                                        Text("ابدأ")
                                    }
                                    OutlinedButton(onClick = { pauseListening() }) {
                                        Icon(Icons.Default.Pause, null)
                                        Text("إيقاف مؤقت")
                                    }
                                    OutlinedButton(onClick = { stopListening() }) {
                                        Icon(Icons.Default.Stop, null)
                                        Text("إيقاف")
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("المحادثة والترجمة", color = Color.White, fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f))
                            IconButton(onClick = { items = emptyList(); error = "" }) {
                                Icon(Icons.Default.Delete, "مسح السجل", tint = Color.LightGray)
                            }
                        }
                        if (error.isNotBlank()) {
                            Text(error, color = Color(0xFFFF8A80), fontSize = 12.sp)
                        }
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(items, key = { it.id }) { item ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF152238)),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(Modifier.padding(14.dp)) {
                                        Text("النص الأصلي • ${sourceLabel(item.language)}",
                                            color = Color(0xFF9DB5D2), fontSize = 11.sp)
                                        Text(item.source, color = Color.White, fontSize = 14.sp)
                                        Spacer(Modifier.height(8.dp))
                                        Text("الترجمة العربية", color = Color(0xFF75C5FF), fontSize = 11.sp)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(item.arabic, color = Color.White, fontSize = 19.sp,
                                                modifier = Modifier.weight(1f))
                                            IconButton(onClick = { speak(item.arabic, speechRate) }) {
                                                Icon(Icons.Default.VolumeUp, "استمع للترجمة", tint = Color(0xFF75C5FF))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("النطق التلقائي", color = Color.White, modifier = Modifier.weight(1f))
                            Switch(checked = autoSpeak, onCheckedChange = { autoSpeak = it })
                        }
                        Text("سرعة الصوت العربي: ${"%.1f".format(speechRate)}×",
                            color = Color.LightGray, fontSize = 12.sp)
                        Slider(value = speechRate, onValueChange = { speechRate = it }, valueRange = 0.7f..1.3f)
                        Text("تُعالج المقاطع النصية فقط؛ لا يتم حفظ التسجيلات الصوتية.",
                            color = Color.Gray, fontSize = 10.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }

    private fun sourceLabel(code: String): String = when (code) {
        "auto" -> "تلقائي (لغة الهاتف)"
        "ru" -> "الروسية"
        "en" -> "الإنجليزية"
        "fr" -> "الفرنسية"
        "es" -> "الإسبانية"
        "de" -> "الألمانية"
        else -> code
    }

    private fun requestAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) startListening()
        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onErrorText?.invoke("خدمة التعرف على الكلام غير متوفرة على هذا الجهاز")
            return
        }
        stopRecognizerOnly()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        listening = true
        paused = false
        restarting = false
        onStatus?.invoke("أستمع الآن…")
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { onStatus?.invoke("أستمع الآن…") }
            override fun onBeginningOfSpeech() { onStatus?.invoke("تم التقاط الكلام") }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { onStatus?.invoke("جارٍ معالجة الكلام…") }
            override fun onError(error: Int) {
                if (listening && !paused) scheduleRestart()
                else if (error != SpeechRecognizer.ERROR_NO_MATCH) onErrorText?.invoke("تعذر التعرف على الكلام (رمز $error)")
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) translate(text)
                if (listening && !paused) scheduleRestart()
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                onPartial?.invoke(text)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        launchRecognizer()
    }

    private fun launchRecognizer() {
        if (!listening || paused) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, when (selectedSource) {
                "auto" -> Locale.getDefault().toLanguageTag()
                else -> selectedSource
            })
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try { recognizer?.startListening(intent) }
        catch (_: Exception) { scheduleRestart() }
    }

    private fun scheduleRestart() {
        if (restarting) return
        restarting = true
        window.decorView.postDelayed({
            restarting = false
            if (listening && !paused) launchRecognizer()
        }, 450)
    }

    private fun translate(text: String) {
        val normalized = text.trim()
        if (normalized.length < 2) return
        val now = System.currentTimeMillis()
        if (normalized == recentFinals.lastOrNull() && now - lastFinalAt < 5000) return
        recentFinals.addLast(normalized)
        while (recentFinals.size > 8) recentFinals.removeFirst()
        lastFinalAt = now

        onStatus?.invoke("جارٍ تحديد اللغة والترجمة…")
        val identifier = LanguageIdentification.getClient()
        identifier.identifyLanguage(normalized)
            .addOnSuccessListener { detected ->
                val lang = if (selectedSource == "auto" && detected != "und") detected else selectedSource
                translateWithLanguage(normalized, lang)
            }
            .addOnFailureListener {
                translateWithLanguage(normalized, if (selectedSource == "auto") "en" else selectedSource)
            }
    }

    private fun translateWithLanguage(text: String, sourceCode: String) {
        val source = TranslateLanguage.fromLanguageTag(sourceCode)
        val target = TranslateLanguage.ARABIC
        if (source == null || source == target) {
            if (source == target) onItem?.invoke(TranscriptItem(source = text, arabic = text, language = "ar"))
            else onErrorText?.invoke("هذه اللغة غير مدعومة للترجمة. اختر الروسية أو الإنجليزية أو الفرنسية أو الإسبانية أو الألمانية.")
            return
        }
        val options = TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build()
        val translator = Translation.getClient(options)
        onStatus?.invoke("جارٍ تجهيز نموذج الترجمة…")
        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(text)
                    .addOnSuccessListener { translated ->
                        onItem?.invoke(TranscriptItem(source = text, arabic = translated, language = sourceCode))
                        onStatus?.invoke(if (listening) "أستمع الآن…" else "اكتملت الترجمة")
                        translator.close()
                    }
                    .addOnFailureListener {
                        onErrorText?.invoke("فشلت الترجمة. تحقق من اتصال الإنترنت وحاول مجدداً.")
                        translator.close()
                    }
            }
            .addOnFailureListener {
                onErrorText?.invoke("تعذر تنزيل نموذج اللغة. اتصل بالإنترنت ثم أعد المحاولة.")
                translator.close()
            }
    }

    private fun speak(text: String, rate: Float = 1f) {
        tts?.setSpeechRate(rate)
        tts?.language = Locale("ar")
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
    }

    private fun pauseListening() {
        paused = true
        listening = false
        stopRecognizerOnly()
        onStatus?.invoke("متوقف مؤقتاً")
    }

    private fun stopListening() {
        listening = false
        paused = false
        stopRecognizerOnly()
        tts?.stop()
        onStatus?.invoke("تم إيقاف الاستماع")
    }

    private fun stopRecognizerOnly() {
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ar")
        }
    }

    override fun onDestroy() {
        listening = false
        stopRecognizerOnly()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
